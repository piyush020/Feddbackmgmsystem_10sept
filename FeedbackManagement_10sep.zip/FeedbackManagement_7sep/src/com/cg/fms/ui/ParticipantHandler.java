package com.cg.fms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.dao.CourseDaoImpl;
import com.cg.fms.dto.Course;
import com.cg.fms.dto.Employee;
import com.cg.fms.dto.Feedback;
import com.cg.fms.dto.ParticipantEnrollment;
import com.cg.fms.dto.Training;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.CourseService;
import com.cg.fms.service.CourseServiceImpl;
import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.ParticipantEnrollmentService;
import com.cg.fms.service.ParticipantEnrollmentServiceImpl;
import com.cg.fms.service.TrainingService;
import com.cg.fms.service.TrainingServiceImpl;

public class ParticipantHandler {
	Employee participant = null;
	CourseService courseService = null;
	ParticipantEnrollmentService partcipantEService = null;
	TrainingService trainingService = null;
	FeedbackService feedbackService = null;

	Scanner sc = new Scanner(System.in);

	public ParticipantHandler(Employee employee) {
		super();
		participant = employee;
		courseService = new CourseServiceImpl();
		partcipantEService = new ParticipantEnrollmentServiceImpl();
		trainingService = new TrainingServiceImpl();
		feedbackService = new FeedbackServiceImpl();
	}

	public void start() throws FMSException {

		System.out.println("Welcome " + participant.getEmployeeName());
		// System.out.println("What do you want to do");

		ArrayList<ParticipantEnrollment> participantList = partcipantEService
				.getParticipantEnrollmentByParticipantId(participant
						.getEmployeeId());

		ArrayList<Training> trainingsAssigned = new ArrayList<>();

		for (ParticipantEnrollment enrollment : participantList) {
			trainingsAssigned.add(trainingService.getTrainingById(enrollment
					.getTrainingCode()));
		}

		ArrayList<Course> courseList = new ArrayList<>();

		for (Training training : trainingsAssigned) {
			courseList
					.add(courseService.getCourseById(training.getCourseCode()));
		}

		System.out.println("List of courses you are enrolled with : ");

		for (int i = 0; i < courseList.size(); i++) {
			System.out.println("Training Code : "
					+ trainingsAssigned.get(i).getTrainingCode() + ", Name : "
					+ courseList.get(i).getCourseName());
		}

		System.out.println("Please enter the training code");

		int x = 1;
		while (1 == x) {
			int trainingCode = sc.nextInt();

			if (trainingsAssigned.contains(trainingCode)) {
				Feedback feedback = takefeedback();
				
				int feedbackReceived=feedbackService.addFeedback(feedback);
				if(feedbackReceived==1) {
					System.out.println("data inserted");
				}
				else
				{
					System.out.println("error in insertion");	
				}
				break;
			
			} else {
				System.out.println("Wrong Training code entered, try again");
			}
		}


		// all menu items, switch case

	}
	public Feedback takefeedback() throws FMSException{
		System.out.println("Enter training code");
		int trainingCode = sc.nextInt();
		System.out.println("Enter partcipant Id");
		int participantId = sc.nextInt();
		System.out.println("rate the presentation and "
				+ "communication of trainer from 0 - 5 ");
		int presentationCommunication=sc.nextInt();
		System.out.println("rate the doubt clarification "
				+ "skill of trainer from 0 - 5 ");
		int clarifyDoubts=sc.nextInt();
		System.out.println("rate time management skill of "
				+ "trainer from 0 - 5 ");
		int timeManagement=sc.nextInt();
		System.out.println("rate the hand out solving skill"
				+ " of trainer from 0 - 5 ");
		int handOut=sc.nextInt();
		System.out.println("rate the harware and software "
				+ "network provided from 0 - 5 ");
		int hwSwNetwork=sc.nextInt();
		System.out.println("Give additional comments if any");
		String comments=sc.nextLine();
		System.out.println("Give any suggestions");
		String suggestions=sc.nextLine();
		
		Feedback feedback = new Feedback(trainingCode, 
				participantId, presentationCommunication, 
				clarifyDoubts, timeManagement, handOut, 
				hwSwNetwork, comments, suggestions);
		
		
       return feedback;
	}
}
