package com.cg.fms.ui;

import com.cg.fms.dto.Employee;

public class CoordinatorHandler {
	
	Employee coordinator;
	
	public CoordinatorHandler(Employee employee) {
		super();
		coordinator = employee;
	}

	public void start(){
		System.out.println("Welcome " + coordinator.getEmployeeName());
		System.out.println("What do you want to do");
		
		//all menu items, switch case 
	}
}
